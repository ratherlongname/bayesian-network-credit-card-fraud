# README

```bash
sudo apt-get install python3 jupyter
pip3 install scikit-learn pandas alibi
jupyter notebook credit-card-fraud.ipynb
# Run all cells in sequence (Shift + Enter) for all cells
```
